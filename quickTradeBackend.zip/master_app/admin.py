from django.contrib import admin
from master_app.models import *

admin.site.register(MastrModel)
