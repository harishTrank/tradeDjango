$(document).ready(function () {
    $('.tab-head li').click(function () {
        var tabId = $(this).attr('data-id');
        $('#' + tabId).show().siblings().hide()
        $(this).addClass('active').siblings().removeClass('active');
    });
    $('.open-menu').click(function () {
        $(".dropdown").toggle();
    })
});