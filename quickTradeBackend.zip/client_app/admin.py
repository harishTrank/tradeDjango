from django.contrib import admin
from client_app.models import *

admin.site.register(ClientModel)
