from django.contrib import admin
from admin_app.models import *


admin.site.register(AdminModel)