import sqlite3
db_path = '/Users/admin/Downloads/quickTradeBackend/db.sqlite3'
connection = sqlite3.connect(db_path)
cursor = connection.cursor()
cursor.execute("SELECT * FROM App_BuyAndSellModel")
data = cursor.fetchall()
print("data",data)
cursor.close()
connection.close()
