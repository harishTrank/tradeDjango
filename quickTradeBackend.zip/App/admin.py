from django.contrib import admin
from App.models import *

admin.site.register(MyUser)
admin.site.register(ExchangeModel)
admin.site.register(MarketWatchModel)
admin.site.register(BuyAndSellModel)
