from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth import authenticate, login
from App.models import *
from client_app.models import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate,login,logout




class LoginView(View):
    def get(self, request):
        if request.user.is_authenticated:
            if request.user is not None and request.user.user_type == "SuperAdmin":
                return redirect("Admin:dashboard")
            elif request.user is not None and request.user.user_type == "Admin":
                return redirect("Admin:dashboard")
            elif request.user is not None and request.user.user_type == "Master":
                return redirect("Admin:dashboard")
            elif request.user is not None and request.user.user_type == "Client":
                return redirect("Admin:dashboard")
        return render(request, "register/login.html")
    
    def post(self, request):
        params = request.POST
        user = authenticate(user_name=params["user_name"], password=params["password"])
        if user is not None and user.user_type == "SuperAdmin":
            login(request,user)
            return redirect("Admin:dashboard")
        elif user is not None and user.user_type == "Admin":
            login(request, user)
            return redirect("Admin:dashboard")
        elif user is not None and user.user_type == "Master":
            login(request, user)
            return redirect("Admin:dashboard")
        elif user is not None and user.user_type == "Client":
            login(request, user)
            return redirect("Admin:dashboard")
        else:
            return redirect("Admin:login")



class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect("Admin:login")
    
    
    
class Dashboard(View):
    def get(self, request):
        if request.user.is_authenticated:
            return render(request, "dashboard/dashboard.html")
        return redirect("Admin:login")
        
    
    
   
class AddUserView(View):
    def get(self, request):
        return render(request, "User/add-user.html")
    
    def post(self, request):
        print("add_master === >",request.POST.get("add_master"))
        user_data = {
            "user_type": "Client",
            "full_name": request.POST.get("full_name"),
            "user_name": request.POST.get("user_name"),
            "phone_number": request.POST.get("phone_number"),
            "city": request.POST.get("city"),
            "credit": request.POST.get("credit"),
            "remark": request.POST.get("remark"),
            "password": make_password(request.POST.get("password")),
            "mcx": True if request.POST.get("mcx").lower() == 'on' else False,
            "nse": True if request.POST.get("nse").lower() == 'on' else False,
            "sgx": True if request.POST.get("sgx").lower() == 'on' else False,
            "others": True if request.POST.get("others").lower() == 'on' else False,
            "mini": True if request.POST.get("mini").lower() == 'on' else False,
            "change_password": True if request.POST.get("change_password").lower() == 'on' else False,
            "add_master": True if request.POST.get("add_master").lower() == 'on' else False,
        }
        user_id = request.user.id
        current_master = MyUser.objects.get(id=user_id).master_user
        create_user = MyUser.objects.create(**user_data)
        if request.POST.get("add_master") == "":
            ClientModel.objects.create(client=create_user, master_user_link=current_master)
        else:
            admin_belongs = current_master.admin_user
        
        mcx_exchange = request.POST.get("mcx_exchange") == 'on'
        mcx_turnover = request.POST.get("mcx_turnover") == 'on'
        mcx_symbol = request.POST.get("mcx_symbol") == 'on'

        nse_exchange = request.POST.get("nse_exchange") == 'on'
        nse_turnover = request.POST.get("nse_turnover") == 'on'
        nse_symbol = request.POST.get("nse_symbol") == 'on'
        
        sgx_exchange = request.POST.get("sgx_exchange") == 'on'
        sgx_turnover = request.POST.get("sgx_turnover") == 'on'
        sgx_symbol = request.POST.get("sgx_symbol") == 'on'

        others_exchange = request.POST.get("others_exchange") == 'on'
        others_turnover = request.POST.get("others_turnover") == 'on'
        others_symbol = request.POST.get("others_symbol") == 'on'
        exchanges = [
        {
            "name": "MCX",
            "exchange": mcx_exchange,
            "symbols": mcx_symbol,
            "turnover": mcx_turnover,
        },
        {
            "name": "NSE",
            "exchange": nse_exchange,
            "symbols": nse_symbol,
            "turnover": nse_turnover,
        },
        {
            "name": "SGX",
            "exchange": sgx_exchange,
            "symbols": sgx_symbol,
            "turnover": sgx_turnover,
        },
        {
            "name": "OTHERS",
            "exchange": others_exchange,
            "symbols": others_symbol,
            "turnover": others_turnover,
        },]
        for exchange_data in exchanges:
            ExchangeModel.objects.create(
                user=create_user,
                symbol_name=exchange_data['name'],
                exchange=exchange_data['exchange'],
                symbols=exchange_data['symbols'],
                turnover=exchange_data['turnover'])
            
        return redirect("Admin:add-user")
        
       
        
        
        

   