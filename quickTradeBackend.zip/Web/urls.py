from django.contrib import admin
from django.urls import path, include
from Web.views import *

urlpatterns = [
    path("",LoginView.as_view(),name="login"),
    path("logout", LogoutView.as_view(), name="logout"),
    path("dashboard",Dashboard.as_view(),name="dashboard"),
    path("add-user",AddUserView.as_view(),name="add-user"),
    
]
